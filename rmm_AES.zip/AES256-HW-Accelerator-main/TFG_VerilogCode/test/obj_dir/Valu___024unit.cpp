// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Valu.h for the primary calling header

#include "Valu___024unit.h"
#include "Valu__Syms.h"

//==========

VL_CTOR_IMP(Valu___024unit) {
    // Reset internal values
    // Reset structure values
    _ctor_var_reset();
}

void Valu___024unit::__Vconfigure(Valu__Syms* vlSymsp, bool first) {
    if (0 && first) {}  // Prevent unused
    this->__VlSymsp = vlSymsp;
}

Valu___024unit::~Valu___024unit() {
}

void Valu___024unit::_ctor_var_reset() {
    VL_DEBUG_IF(VL_DBG_MSGF("+        Valu___024unit::_ctor_var_reset\n"); );
}
